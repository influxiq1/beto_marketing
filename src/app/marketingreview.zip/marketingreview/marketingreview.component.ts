import { Component, OnInit } from '@angular/core';
 

 

@Component({
  selector: 'app-marketingreview',
  templateUrl: './marketingreview.component.html',
  styleUrls: ['./marketingreview.component.css']
})
export class MarketingreviewComponent implements OnInit {

  public timezoneval:any;
  public filterval5:any;
 
  
  constructor() {


    
   }

  ngOnInit() {

    console.warn(this.marketingreView); 
  }

  marketingreView= [
    {id:"1",   title:"1 There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, ", date:"03/10/2020", time:"00:00 AM -  00:00 PM", timezone:"Time zone : Australian Central Daylight TimeAdelaide (GMT+10:30)", },
    {id:"2",   title:"2 There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, ", date:"03/10/2020", time:"00:00 AM -  00:00 PM", timezone:"Time zone : Australian Central Daylight TimeAdelaide (GMT+10:30)", },
    {id:"3",   title:"3 There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, ", date:"03/10/2020", time:"00:00 AM -  00:00 PM", timezone:"Time zone : Australian Central Daylight TimeAdelaide (GMT+10:30)", },
    {id:"4",   title:"4 There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, ", date:"03/10/2020", time:"00:00 AM -  00:00 PM", timezone:"Time zone : Australian Central Daylight TimeAdelaide (GMT+10:30)", },
    {id:"5",   title:"5 There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, ", date:"03/10/2020", time:"00:00 AM -  00:00 PM", timezone:"Time zone : Australian Central Daylight TimeAdelaide (GMT+10:30)", },
    {id:"6",   title:"6 There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, ", date:"03/10/2020", time:"00:00 AM -  00:00 PM", timezone:"Time zone : Australian Central Daylight TimeAdelaide (GMT+10:30)", },
    {id:"7",   title:"7 There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, ", date:"03/10/2020", time:"00:00 AM -  00:00 PM", timezone:"Time zone : Australian Central Daylight TimeAdelaide (GMT+10:30)", },
    {id:"8",   title:"8 There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, ", date:"03/10/2020", time:"00:00 AM -  00:00 PM", timezone:"Time zone : Australian Central Daylight TimeAdelaide (GMT+10:30)", },
    {id:"9",   title:"9 There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, ", date:"03/10/2020", time:"00:00 AM -  00:00 PM", timezone:"Time zone : Australian Central Daylight TimeAdelaide (GMT+10:30)", },
    {id:"10",  title:"10 There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, ", date:"03/10/2020", time:"00:00 AM -  00:00 PM", timezone:"Time zone : Australian Central Daylight TimeAdelaide (GMT+10:30)", },
     
  
     
   

]
  

}
